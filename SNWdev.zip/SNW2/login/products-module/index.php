<div id="third-submenu">
    <a href="index.php?page=product" class="move">List of Products</a>
    <a href="index.php?page=product&action=create" class="move">New Product</a>
    <a href="index.php?page=product&action=types" class="move">Product Types</a>
</div>
<div id="subcontent">
    <?php
      switch($action){
                case 'create':
                    require_once 'products-module/create-product.php';
                break; 
                case 'modify':
                    require_once 'products-module/modify-product.php';
                break; 
                case 'profile':
                    require_once 'products-module/view-product.php';
                break;
                case 'types':
                    require_once 'products-module/list-product-types.php';
                break;
                default:
                    require_once 'products-module/main.php';
                break; 
            }
    ?>
  </div>