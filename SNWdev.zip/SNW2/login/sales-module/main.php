<h3>Sales List</h3>
<div id="subcontent">
    <table id="data-list">
      <tr>
        <th>Name</th>
        <th>Orders</th>
        <th>Price</th>
        <th>Sales Value</th>
      </tr>
<?php
$count = 1;
$count = 1;
if($sales->list_instock() != false){
foreach($sales->list_instock() as $value){
   extract($value);
  
?>
      <tr>
        <td><a href="index.php?page=settings&subpage=users&action=profile&id=<?php echo $prod_id;?>"><?php echo $prod_name;?></a></td>
        <td style="text-align: center;"><?php echo $sales->get_product_order_sales($prod_id);?></td>
        <td style="text-align: center;"><?php echo $product->get_prod_price($prod_id);?></td>
        <td style="text-align: center;"><?php echo $sales->get_product_order_sales($prod_id) - $sales->get_product_order_sales($prod_id);?></td>
        
      </tr>
      <tr>
<?php
 $count++;
}
}else{
  echo "No Record Found.";
}
?>
    </table>
</div>